package com.fittop.lxx.mvpmoshi.ui.activity;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;

import com.fittop.lxx.mvpmoshi.AppApplication;
import com.fittop.lxx.mvpmoshi.AppComponent;

/**
 * Created by Administrator on 2017/5/31.
 */

public abstract class BaseActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupActivityComponent(AppApplication.get(this).getAppComponent());

    }

    protected abstract void setupActivityComponent(AppComponent appComponent);

}
