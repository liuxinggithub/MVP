package com.fittop.lxx.mvpmoshi;

import android.app.Application;

import com.fittop.lxx.mvpmoshi.data.AppServiceModule;
import com.fittop.lxx.mvpmoshi.data.api.ApiService;
import com.fittop.lxx.mvpmoshi.data.api.ApiServiceModule;
import com.fittop.lxx.mvpmoshi.module.User;

import javax.inject.Singleton;

import dagger.Component;

/**
 * Created by lxx on 2017/5/31.
 */
@Singleton
@Component(modules = {AppModule.class, ApiServiceModule.class, AppServiceModule.class})
public interface AppComponent {

    Application getApplication();

    ApiService getService();

    User getUser();

}
