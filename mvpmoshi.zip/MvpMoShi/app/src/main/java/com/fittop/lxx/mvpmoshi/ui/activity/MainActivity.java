package com.fittop.lxx.mvpmoshi.ui.activity;


import android.os.Bundle;
import android.widget.TextView;

import com.fittop.lxx.mvpmoshi.AppComponent;
import com.fittop.lxx.mvpmoshi.R;
import com.fittop.lxx.mvpmoshi.ui.activity.component.DaggerMainActivityComponent;
import com.fittop.lxx.mvpmoshi.ui.activity.module.MainActivityModule;
import com.fittop.lxx.mvpmoshi.ui.activity.presenter.MainAcitvityPresenter;

import javax.inject.Inject;

import butterknife.ButterKnife;
import butterknife.InjectView;

public class MainActivity extends BaseActivity {

    /**
     * 注入
     * */
    @InjectView(R.id.tv)
    TextView textView;
    @Inject
    MainAcitvityPresenter presenter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.inject(this);
        presenter.showUserName();
    }

    @Override
    protected void setupActivityComponent(AppComponent appComponent) {
        DaggerMainActivityComponent.builder()
                .appComponent(appComponent)
                .mainActivityModule(new MainActivityModule(this))
                .build()
                .inject(this);
    }

    public void setTextView(String username){
        textView.setText(username);
    }

}
