package com.fittop.lxx.mvpmoshi.ui.activity.component;

import com.fittop.lxx.mvpmoshi.AppComponent;
import com.fittop.lxx.mvpmoshi.ui.activity.ActivityScope;
import com.fittop.lxx.mvpmoshi.ui.activity.MainActivity;
import com.fittop.lxx.mvpmoshi.ui.activity.module.MainActivityModule;
import com.fittop.lxx.mvpmoshi.ui.activity.presenter.MainAcitvityPresenter;

import dagger.Component;

/**
 * Created by Administrator on 2017/5/31.
 */
@ActivityScope
@Component(modules = MainActivityModule.class,dependencies = AppComponent.class)
public interface MainActivityComponent {
    MainActivity inject(MainActivity mainActivity);
    MainAcitvityPresenter presenter();
}
