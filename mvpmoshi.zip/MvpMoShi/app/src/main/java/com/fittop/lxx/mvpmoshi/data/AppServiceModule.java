package com.fittop.lxx.mvpmoshi.data;

import com.fittop.lxx.mvpmoshi.module.User;

import dagger.Module;
import dagger.Provides;

/**
 * Created by Administrator on 2017/5/31.
 */
@Module
public class AppServiceModule {

    @Provides
    User provideUser() {
        User user = new User();
        user.setId("1");
        user.setName("hello Mvp");
        return user;

    }


}
