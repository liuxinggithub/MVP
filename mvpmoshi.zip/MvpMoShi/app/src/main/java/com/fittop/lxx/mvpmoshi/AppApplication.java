package com.fittop.lxx.mvpmoshi;

import android.app.Application;
import android.content.Context;
import android.database.ContentObservable;

import com.fittop.lxx.mvpmoshi.data.AppServiceModule;
import com.fittop.lxx.mvpmoshi.data.api.ApiServiceModule;

/**
 * Created by Administrator on 2017/5/31.
 */

public class AppApplication extends Application {

    private AppComponent appComponent;

    public static AppApplication get(Context context){
        return (AppApplication)context.getApplicationContext();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        appComponent=DaggerAppComponent.builder()
                .appModule(new AppModule(this))
                .apiServiceModule(new ApiServiceModule())
                .appServiceModule(new AppServiceModule())
                .build();
    }


    public AppComponent getAppComponent() {
        return appComponent;
    }

}
