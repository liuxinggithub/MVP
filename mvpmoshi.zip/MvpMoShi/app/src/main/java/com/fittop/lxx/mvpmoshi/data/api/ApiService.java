package com.fittop.lxx.mvpmoshi.data.api;

import com.fittop.lxx.mvpmoshi.module.User;

import java.util.List;

import retrofit.Callback;
import retrofit.http.GET;


/**
 * Created by Administrator on 2017/5/31.
 */

public interface ApiService {

    @GET("/users")
    public void getUsers(Callback<List<User>> callback);
}
