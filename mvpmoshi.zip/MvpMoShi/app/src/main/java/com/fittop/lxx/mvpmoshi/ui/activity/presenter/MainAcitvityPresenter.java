package com.fittop.lxx.mvpmoshi.ui.activity.presenter;

import com.fittop.lxx.mvpmoshi.module.User;
import com.fittop.lxx.mvpmoshi.ui.activity.MainActivity;

/**
 * Created by Administrator on 2017/5/31.
 */

public class MainAcitvityPresenter {

    private MainActivity mainActivity;
    private User user;

    public MainAcitvityPresenter(MainActivity mainActivity,User user) {
        this.mainActivity=mainActivity;
        this.user=user;
    }

    public void showUserName(){

        mainActivity.setTextView(user.getName());
    }


}
