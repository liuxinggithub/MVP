package com.fittop.lxx.mvpmoshi.ui.activity;

import javax.inject.Scope;

/**
 * Created by Administrator on 2017/5/31.
 */
@Scope
public @interface ActivityScope {
}
