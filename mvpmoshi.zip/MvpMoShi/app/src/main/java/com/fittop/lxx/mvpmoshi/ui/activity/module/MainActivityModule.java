package com.fittop.lxx.mvpmoshi.ui.activity.module;

import com.fittop.lxx.mvpmoshi.module.User;
import com.fittop.lxx.mvpmoshi.ui.activity.ActivityScope;
import com.fittop.lxx.mvpmoshi.ui.activity.MainActivity;
import com.fittop.lxx.mvpmoshi.ui.activity.presenter.MainAcitvityPresenter;

import dagger.Module;
import dagger.Provides;

/**
 * Created by Administrator on 2017/5/31.
 */
@Module
public class MainActivityModule {

    private MainActivity mainActivity;

    public MainActivityModule(MainActivity mainActivity){this.mainActivity=mainActivity;}


    @Provides
    @ActivityScope
    MainActivity provodeMainActivity(){return mainActivity;}

    @Provides
    @ActivityScope
    MainAcitvityPresenter provideMainActivityPresenter(MainActivity mainActivity, User user){

        return  new MainAcitvityPresenter(mainActivity,user);
    }



}
